-- CreateTable
CREATE TABLE "Admin" (
    "id" TEXT NOT NULL,
    "email" TEXT NOT NULL,
    "password" TEXT NOT NULL,

    CONSTRAINT "Admin_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "OriginalApi" (
    "id" TEXT NOT NULL,
    "apiUrl" TEXT NOT NULL,
    "apiKey" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "restoredAPIid" TEXT,

    CONSTRAINT "OriginalApi_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "FinishedAPI" (
    "id" TEXT NOT NULL,
    "items" JSONB NOT NULL DEFAULT '[]',
    "userId" TEXT NOT NULL,

    CONSTRAINT "FinishedAPI_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "RestoredAPI" (
    "id" TEXT NOT NULL,
    "adminId" TEXT NOT NULL,

    CONSTRAINT "RestoredAPI_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "User" (
    "id" TEXT NOT NULL,
    "email" TEXT NOT NULL,
    "password" TEXT NOT NULL,
    "adminId" TEXT,

    CONSTRAINT "User_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "Admin_email_key" ON "Admin"("email");

-- CreateIndex
CREATE UNIQUE INDEX "User_email_key" ON "User"("email");

-- AddForeignKey
ALTER TABLE "OriginalApi" ADD CONSTRAINT "OriginalApi_restoredAPIid_fkey" FOREIGN KEY ("restoredAPIid") REFERENCES "RestoredAPI"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "OriginalApi" ADD CONSTRAINT "OriginalApi_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "FinishedAPI" ADD CONSTRAINT "FinishedAPI_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "RestoredAPI" ADD CONSTRAINT "RestoredAPI_adminId_fkey" FOREIGN KEY ("adminId") REFERENCES "Admin"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "User" ADD CONSTRAINT "User_adminId_fkey" FOREIGN KEY ("adminId") REFERENCES "Admin"("id") ON DELETE SET NULL ON UPDATE CASCADE;
